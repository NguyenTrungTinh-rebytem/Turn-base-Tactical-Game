#include "entities/Player.h"
#include "data/Skill.h"

Player::Player(const std::string& name, const Stats& stats, Element element)
    : Character(name, stats, element)
{
}

// Player phải đủ MP mới dùng được skill.
void Player::executeSkill(Skill* skill, Character* target)
{
    if (!canAct(skill, target)) return;
    if (m_currentMp < skill->m_mpCost) return;  // Không đủ MP: bỏ qua

    m_currentMp -= skill->m_mpCost;
    target->takeDamage(calcSkillDamage(skill), skill->m_element, skill->m_isMagic);
}